﻿module AcidHelperAcidPetals

using ..Ahorn, Maple

@mapdef Effect "AcidHelper/AcidPetals" AcidPetals()

placements = AcidPetals

function Ahorn.canFgBg(AcidPetals)
    return true, true
end

end