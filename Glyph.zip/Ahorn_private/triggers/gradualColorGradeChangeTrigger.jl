﻿module AcidHelperGradualColorGradeChangeTrigger

using ..Ahorn, Maple

@mapdef Trigger "AcidHelper/GradualColorGradeChangeTrigger" GradualColorGradeChangeTrigger(x::Integer, y::Integer, width::Integer=Maple.defaultTriggerWidth, height::Integer=Maple.defaultTriggerHeight,
    speed::Number=1.0, colorGrade::String="none")

const placements = Ahorn.PlacementDict(
    "Gradual Color Grade Change Trigger (Acid helper)" => Ahorn.EntityPlacement(
        GradualColorGradeChangeTrigger,
        "rectangle"
    )
)

end
