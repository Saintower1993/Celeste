﻿module AcidHelperSavedFlagTrigger

using ..Ahorn, Maple

@mapdef Trigger "AcidHelper/SavedFlagTrigger" SavedFlagTrigger(x::Integer, y::Integer, width::Integer=Maple.defaultTriggerWidth, height::Integer=Maple.defaultTriggerHeight,
    flag::String="foo")

const placements = Ahorn.PlacementDict(
    "Saved Flag Trigger (Acid helper)" => Ahorn.EntityPlacement(
        SavedFlagTrigger,
        "rectangle"
    )
)

end
