﻿module AcidHelperInstantTeleportTrigger

using ..Ahorn, Maple

@mapdef Trigger "AcidHelper/InstantTeleportTrigger" InstantTeleportTrigger(x::Integer, y::Integer, width::Integer=Maple.defaultTriggerWidth, height::Integer=Maple.defaultTriggerHeight,
    targetRoomId::String="foo", respawn::Bool=true, soundEventId::String="foo", killMusicOnTransition::Bool=false)

const placements = Ahorn.PlacementDict(
    "Instant Teleport Trigger (Acid helper)" => Ahorn.EntityPlacement(
        InstantTeleportTrigger,
        "rectangle"
    )
)

end
