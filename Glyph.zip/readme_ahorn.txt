This mod has a private helper called Acid helper, intended to be used only for this mod.
I've kept the ahorn file in the mod for educational purposes. If you'd like to see the entities
within ahorn, rename the "Ahorn_private" file to "Ahorn".

Please do not use AcidHelper for your own modded content. Thanks!
Marshall h