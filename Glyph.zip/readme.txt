~~Glyph Version 2.3.3~~

Hi thanks for playing this map! this was created by Marshall H (marshall#9018 on discord)

Chapter artwork was made by the talented Fuwamo -- I strongly encourage you check out their art, it's all amazing!
https://twitter.com/iloli_i8g

MAIN MAP INFO
---------
Maddie goes on a journey through the mind & memories of one that are not her own. 
An impressionistic map that _should_ be suitably challenging for advanced players of Celeste.

100+ rooms
30+ berries
1 Crystal Heart...?
Lots of ~~~secrets~~~ and some (arguably egregious) esoteric shit if you're into that
30+ minutes of original music & SFX
lotsa custom codez

Difficulty: Slightly more difficult than Farewell. Some berries are very difficult to get.
Tech required: Wallbounces, wavedashing, etc. Nothing that you haven't had to do in Farewell. Neutrals are disabled.

SEASON-SIDES
------------

Aka Glyph B-sides, but for each season! Plus a bonus, shorter void-side.

~95 rooms total
No berries, no secrets in these, just level.

Difficulty: Harder than the main chapter for sure. But not by much.
Tech required: Same as main map. Neutrals are still disabled. 

Dependencies:
Frost Helper (https://gamebanana.com/gamefiles/9201)
Extended Variants Mode (https://gamebanana.com/gamefiles/9486)
AltSidesHelper (https://gamebanana.com/mods/166210)
Glyph Audio (https://gamebanana.com/gamefiles/11936)

DISCLAIMERS
------------
- Neutrals are force disabled via extended variants. I did this because I think they sort of ruin 
gameplay. Which is ironic because my first map (Sibs tower) is basically neturals, the map.
- Debug mode will probably break things, use at your own peril
- Photosensetive mode enabled might make the transitions between rooms a little funky looking but that's okay. 
I recommend keeping photosensitivity mode disabled if you do not require the feature and it is safe for you to do so.
- Playing Sib's Crane beforehand might help contextualize some of the content in this map. Though it is not at all required.
- Yes, if it isn't obvious already, i love fez and hyper light drifter, and i draw a lot of inspiration from those games and music.

SPECIAL THANKS
---------------
+ (2.3.0) Natalie and Lily for a ridiculously helpful feedback document outlining a ton of small issues. That feedback motivated me
  to make the 2.3.0 update.
+ (2.3.0) Luna for alt-sides helper! And the active support and help during the implementation process.
+ 0x0ade, for not only creating everest and being the reason why im doing this at all, but for giving me the ok to re-appropriate the teleporter code they used in Celsius.
Go play it, its an amazing mod!! Support them here: https://www.patreon.com/0x0ade/posts
+ CANADIAN, for being unbelievably helpful with feedback and suggestions in playtesting. Really just an incredible amount of help, THANK YOU.
+ max480, for extended variants and generally being one of the most helpful and optimistic contributors to the celeste modding community.
+ jatheplayer for frost helper, which I used here for custom spinner colors and lightning color changes.
+ Cruor and Vex for being vital parts of the modding dev community. Ahorn is amazing
+ Natalie for the wonderful guidance in resolving the strawberry duping issue
+ iamdadbod, for playtesting & supporting the void-b-side!
+ Fuwamo for artwork! Support them here: https://twitter.com/iloli_i8g

SFX CREDITS
------------
Desert wind sound, thanks to Proxima4 https://freesound.org/people/Proxima4/sounds/104320/
Rustling Winds (used in Sib's legacy chapter) thanks to FunWithSound https://freesound.org/people/FunWithSound/sounds/381381/
Hawk Sounds (used in Sib's legacy chapter) thanks to reidedo https://freesound.org/people/reidedo/sounds/344445/
Birds Singing in the Morning (used in School of the Flower chapter) thanks to Alexander http://www.orangefreesounds.com/birds-singing-in-the-morning/

------
thanks have fun playing this, this was super fun to make!
im receptive to feedback if its actionable so do give me a shout if you find bugs or have any issues!
reach out to me on discord if you'd like (marshall#9018 on discord)
or email at lushboystudios@gmail.com
or check out this super amateur 2d platformer i made two years ago called luna https://store.steampowered.com/app/666810/Luna/
if you want to use this music for anything please ask first!
cheers xoxo
-----
----
---
--
-
-
--
---
----
------
---------
Changelog
---------

2.3.3
  - Remove IntroType from map meta.yaml files

2.3.2
  - Translations added for all language (Huge thanks to Lily for management and collection of translations)
  - Chapter select scarfs and full clear displays added (Another huge thank you to Lily!)
  - [glyph] [cold-10] adjust top-most spring and spinners to improve feel
  - [glyph] [memory-00/13] remove stray girder tile
  - [glyph] [cold-03] close up alternate upper path
  - [winter-side] [cold-03] move left-side spring down one tile for improved feel
  - [void-b] this chapter can now be full cleared

  Translation Credits: 
    + Lily for management and collection of translations.
    + Kilobit for the Brazilian Portuguese translation.
    + danesky for the Japanese translation.
    + Schroume for the French translation.
    + Ludo_owo for the Italian translation.
    + B1ackZer0 and Vexatos for the German translation.
    + Kosei for the Spanish translation.
    + P3RL for the Russian translation.
    + tofu and WEGFan for the Simplified Chinese translation.
    + Myztic for the Korean translation.

2.3.1
  - Hide ahorn file from ahorn application's reach to prevent people from unwittingly using the entities.
  - [fall side] [chp2-fall-08] remove spikes that bled into next room
  - [summer side] deadgrass fgtile additions
  - [glyph] [peace-06] replace wrong grass fg tiles
  - [glyph] [memory-10a/b] fix lightning incongruency between rooms
  - [glyph] [heat-03] add a missing exit block
  - [voib-b] [crane-blue-05] add some fg tiles at beginning of room

2.3.0
  - tons of things, mostly small! changelog found here: https://docs.google.com/document/d/1gVUsP7RZRZapRM_uIKFsVPhueyUr-UmHaCdInTwO-hs/edit?usp=sharing

2.2.3
  - [Void B-Side] add fg tiles to crane-void-07

2.2.2
  - [Void B-Side] improve camera in crane-pink-01, crane-red-02/04, crane-blue-06, crane-void-06/07/08
  - [Void B-Side] minor gameplay tweak to crane-red-04
  - [Void B-Side] wallbounce adjustment on crane-blue-02
  - [Void B-Side] make final room larger in height for cosmetic reasons

2.2.1
  - [Void B-Side] add trigger spikes to falling block in crane-pink-05
  - [Void B-Side] fix music not starting again after a save & quit
  - [Void B-Side] fix erronous spike placement in crane-blue-01
  - [Void B-Side] remove slippy walls in crane-void-03
  - [Void B-Side] add missing watchtower to crane-void-04

2.2.0
  - Void-B-Side released
  - Requires Glyph Audio 1.2.0
  - New double booster entity to replace all red boosters with double refills inside
  - [Fall-Side] crane-gold-2 reworked to make more consistent / fair
  - [Fall-Side] fixed delayed audio bug during transition to the void
  - [Main Chapter] fall-08 camera rework and some spinner nerfs to make wavedashing for strawberry viable
  - [Main-Chapter] small tweaks to solace rooms 01, 02
  - [Void-Side] B-side Cassette added to end of chapter
  - [Void-Side] Small tweaks to crane-void rooms 06, 07, 08
  - 

2.1.2
  - main chapter: minor room resize to heat-00-05
  - peace-14b -- adjust touch switch gate position to make more lenient
  - spinner adjustments to heat-00-01, heat-00-02, heat-00-03, cold-04, cold-06, fall-08
  - minor camera adjustments to cold-00 and cold-08
  - minor buffs to heat-04 and heat-06 (also spinner adjustments)
  - change portal color in fall rooms from 2C1400
  - crane-blue-03 (winter side) room nerfed slightly to make it more consistent
  - lightning adjustments in city

2.1.1
  - minor resize to room in memories and room in springsize to make for a better camera experience
  - minor nerf for berry in ides of frost beginning

2.1.0
- a lot of QOL across many rooms in the main chapter and the seasonsides. mostly nerfs to rooms that i noticed people had a harder time with or rooms that felt unfair.
	lots of spinner adjustments, removal of some, addition of others. various entity shifting and removing/adding/repositioning to hopefully improve the experience for
	casual players
- cycle issues in spring side fixed (sorry speedrunners)
- spinner color in summer rooms adjusted to be more visible

2.0.8
-- use better custom ice walls for all relevant parts in main chapter (they are used in springside)
-- remove some dumb invisible barriers
-- minor tweak to peace-02 to make hopefully more clear

2.0.7
-- put double refills inside red boosters on void levels and add visual indicator to help with fast bubbling strats
-- loosen up a couple sections in pink void and gold void

2.0.6
-- clean up spinners slighty in winter-side room
-- fix audio bugs for areas in main map

2.0.5
-- fix bad spinner placement in cold

2.0.4
-- add portal to room in heat for TAS

2.0.3
-- remove bigger cheeses in peace-04, crane-void-06, and crane-void-09

2.0.2
-- more minor camera tweaks

2.0.1
-- minor camera tweaks
-- minor additions to crane-void-06
-- oob lightning fixes

2.0.0
-- Add Season-Sides
-- Remove Audio from Base mod, instead add it as a dependency, downloaded separately. Should make future updates far less painful

1.2.4
-- remove accidental invisible troll spike in cold-00
-- increase size of teleportation watchtower window in peace-24

1.2.3
-- make trippy section more readable in general. i've come to learn based on feedback that the distortion, while fun in theory, was just a little too much for fun.
	as a result i've toned down the distorion in that section considerably.

1.2.2
**Disclaimer: I've kept track on the current speedrun meta for this game and none of the following changes should impact the run negatively. 
It may in fact speed up the run (albeit very slightly) in places.

-- fix transition softlock in cold-11
-- very slight nerfs and QOL improvments to screens in memories.
-- slight nerf peace-17 to account for block boost bugs
-- add a teleporter viewer to heat-00-05
-- micro adjustment to fg tile in heat-09 to guard against potential fg tile clip

1.2.1
-- fix frame-perfect respawn exploit in memory-11
-- nerf fall-06 slightly
-- adust portal on fall-04a to help speedrun

1.2.0
-- golden berry added (thank you to natalie for helping me!!)
-- minor camera improvements in crane-01, memory-01, memory-13, peace-10
-- deco addition in peace-06
-- fix potential respawn issue in memory-11
-- deco adjustment in heat-09
-- set checkpoint id's properly (as i foolishly did not before)
-- fix potential ground clip in heat room

1.1.8
-- make all rooms assist-mode friendly
-- change respawn point to make a little less awkward in memories-19a
-- bloom and lighting fix for first checkpoint (tas)
-- add some helpful fgtiles in heat-ll

1.1.7
-- fix frame-perfect respawn issues across the map. I think i got em all this time.
-- add lookout blocker to heat-06

1.1.6
-- fix issue where frame-perfect restarts ignore change respawn triggers in heat-00-05 and heat-00-02
-- include failsafe for rare color grade issue at beginning of map where screen turns permanently white
-- reduce descending seek speed for memories music progress parameter to help drums feel less jarring
-- remove two spinners at heat-09 to prevent accidental wallbounce death upon ascent

1.1.5
-- fix color grade getting stuck in white at beginning of School of the Flower
-- minor tileset change to one room to prevent accidental trolling

1.1.4
-- de-cheese room cold-01 & a very, very minor buff, hopefully making intended strategies to solve more clear
-- very slight buff to cold-06

1.1.3
- change teleporter colors in fall from yellow to brown to help with visibility
- re-add lightbeams to cold-04

1.1.2
- fix speedrun timer reset bug
- very, very slight buff to fall-04
- fixed softlock potential of fall-02 and fall-08 
- fix game crashing target trigger in fall-08

1.1.1
- a lot of very small nerfs to checkpoint 5
- addition of watchtower to room in checkpoint 5
- made teleporters more visible in checkpoint 5
- very slight nerf to fall-11a to help with readability

1.1.0
- add a new endgame checkpoint to make life easier for those who want to explore stuff but not have to use debug mode to get there

1.0.8
- fix respawn issue in chapter 5
- nerf the janky room even more

1.0.7
- changed the jankiest room (i thought) in the game to include an alternate strategy
- fix some more respawn issues
- final room adjustments to hopefully ease some pain points
- screen transition fix at beginning of ides of frost

1.0.6:
- fix respawns in heat-00-05 and fall-15
- remove lightbeam at cold-04
- tighten up cold-08
- out of bounds lightning fixes
- fix strawberry cheeses
- fix transitions mishaps
- fall-03 tweak

1.0.5 - more consistency in chapter 5, chapter 4 tweak
1.0.4 - slight nerf to end of room jank
1.0.3 - decal update
1.0.2 - fix ambience trigger in ides of frost, cosmetic electricity adjustments
1.0.1 - minor QOL changes, and (hopefully) fixes a bug that crashes the game when you teleport to a new room and die at the same time.
1.0.0 - first release

